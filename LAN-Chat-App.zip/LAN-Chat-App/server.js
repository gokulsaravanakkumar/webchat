const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static("public"));

let users = {};

io.on("connection", (socket) => {

    console.log("User connected: " + socket.id);

    socket.on("join", (username) => {
        users[socket.id] = username;
        io.emit("message", username + " joined the chat");
    });

    socket.on("chatMessage", (msg) => {
        io.emit("chatMessage", {
            user: users[socket.id],
            message: msg
        });
    });

    socket.on("disconnect", () => {
        io.emit("message", users[socket.id] + " left the chat");
        delete users[socket.id];
    });

});

server.listen(3000, () => {
    console.log("Server running on port 3000");
});