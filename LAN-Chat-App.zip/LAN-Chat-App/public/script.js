const socket = io();

let username = prompt("Enter your name");

document.getElementById("userLabel").innerText = "(" + username + ")";

socket.emit("join", username);

function sendMessage(){

let input = document.getElementById("msg");

if(input.value.trim() === "") return;

socket.emit("chatMessage", input.value);

input.value = "";
}

socket.on("chatMessage", function(data){

let box = document.getElementById("messages");

let div = document.createElement("div");

div.classList.add("message");

if(data.user === username){
div.classList.add("me");
}else{
div.classList.add("other");
}

div.innerHTML = "<b>"+data.user+"</b><br>"+data.message;

box.appendChild(div);

box.scrollTop = box.scrollHeight;

});

socket.on("message", function(msg){

let box = document.getElementById("messages");

let div = document.createElement("div");

div.classList.add("message","other");

div.innerHTML = "<i>"+msg+"</i>";

box.appendChild(div);

});